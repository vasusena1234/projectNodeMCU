sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, MessageToast) {
        "use strict";

        return Controller.extend("notification.app.controller.View1", {
            onInit: function () {
                var oModel = new JSONModel();
                this.getView().setModel(oModel,"notification");
                this.fetchData();
            },

            fetchData: function() {
                var that = this;
                jQuery.ajax({
                  url: "/salesOrderData",
                  method: "GET",
                  dataType: "json",
                  success: function(data) {
                    that.getView().getModel().setData(data);
                  },
                  error: function() {
                    MessageToast.show("Failed to fetch data from the API.");
                  }
                });
            }
        });
    });
