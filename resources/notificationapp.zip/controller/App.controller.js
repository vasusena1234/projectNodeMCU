sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("notification.app.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map