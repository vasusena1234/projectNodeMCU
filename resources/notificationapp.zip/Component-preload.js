//@ui5-bundle notification/app/Component-preload.js
sap.ui.require.preload({
	"notification/app/Component.js":function(){
sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","notification/app/model/models"],function(e,i,t){"use strict";return e.extend("notification.app.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(t.createDeviceModel(),"device")}})});
},
	"notification/app/controller/App.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("notification.app.controller.App",{onInit(){}})});
},
	"notification/app/controller/View1.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller","sap/ui/model/json/JSONModel","sap/m/MessageToast"],function(t,e,a){"use strict";return t.extend("notification.app.controller.View1",{onInit:function(){var t=new e;this.getView().setModel(t,"notification");this.fetchData()},fetchData:function(){var t=this;jQuery.ajax({url:"/salesOrderData",method:"GET",dataType:"json",success:function(e){t.getView().getModel().setData(e)},error:function(){a.show("Failed to fetch data from the API.")}})}})});
},
	"notification/app/i18n/i18n.properties":'# This is the resource bundle for notification.app\n\n#Texts for manifest.json\n\n#XTIT: Application name\nappTitle=IOTApp\n\n#YDES: Application description\nappDescription=A Fiori application.\n#XTIT: Main view title\ntitle=IOTApp',
	"notification/app/manifest.json":'{"_version":"1.49.0","sap.app":{"id":"notification.app","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"0.0.1"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","sourceTemplate":{"id":"@sap/generator-fiori:basic","version":"1.9.7","toolsId":"a8c60aa2-8f98-4bae-9557-2668402e1577"}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":true,"dependencies":{"minUI5Version":"1.114.0","libs":{"sap.m":{},"sap.ui.core":{},"sap.f":{},"sap.suite.ui.generic.template":{},"sap.ui.comp":{},"sap.ui.generic.app":{},"sap.ui.table":{},"sap.ushell":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"notification.app.i18n.i18n"}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"notification.app.view","controlAggregation":"pages","controlId":"app","clearControlAggregation":false},"routes":[{"name":"RouteView1","pattern":":?query:","target":["TargetView1"]}],"targets":{"TargetView1":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"View1","viewName":"View1"}}},"rootView":{"viewName":"notification.app.view.App","type":"XML","async":true,"id":"App"}}}',
	"notification/app/model/models.js":function(){
sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"notification/app/view/App.view.xml":'<mvc:View controllerName="notification.app.controller.App"\n    xmlns:html="http://www.w3.org/1999/xhtml"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><App id="app"></App></mvc:View>\n',
	"notification/app/view/View1.view.xml":'<mvc:View controllerName="notification.app.controller.View1"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><Page id="page" title="{i18n>title}"><content /></Page></mvc:View>\n'
});
//# sourceMappingURL=Component-preload.js.map
